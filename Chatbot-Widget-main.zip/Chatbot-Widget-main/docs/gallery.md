# Gallery

## Botpop Intro

![ScreenShot](../static/img/botPopup.PNG)

## Text

![ScreenShot](../static/img/chats.png)

## Buttons

![ScreenShot](../static/img/ui_1.PNG)

## Images

![ScreenShot](../static/img/ui_2.PNG)

## Videos

![ScreenShot](../static/img/video_msg.PNG)

## Quick Replies

![ScreenShot](../static/img/cardsUi_3.png)

## PDF Attachment

![ScreenShot](../static/img/pdf_attachment.PNG)

## Charts

![ScreenShot](../static/img/charts_1.png) 
![ScreenShot](../static/img/charts_2.png) 

## Collapsible
![ScreenShot](../static/img/collapse_1.png) 
![ScreenShot](../static/img/collapse_2.png) 

## Card Carousels

![ScreenShot](../static/img/cardsUi.png) 
![ScreenShot](../static/img/cardsUi_2.png) 

